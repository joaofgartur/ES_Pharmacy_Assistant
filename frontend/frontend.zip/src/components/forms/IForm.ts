interface IForm {
    type: string
}

export default IForm;