interface INavbarLogo {
    title: string;
}

export default INavbarLogo;