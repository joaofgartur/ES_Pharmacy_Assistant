import './Button.css'

function Button() {
    return (
        <button>

        </button>
    )
}

export default Button
