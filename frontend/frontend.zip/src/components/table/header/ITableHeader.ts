interface ITableHeader {
    header: Array<string>;
}

export default ITableHeader;