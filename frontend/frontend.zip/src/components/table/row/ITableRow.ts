interface ITableRow {
    id: number;
    content: Array<string>;
}

export default ITableRow;