
interface IButton {
    title: string
}

export default IButton;