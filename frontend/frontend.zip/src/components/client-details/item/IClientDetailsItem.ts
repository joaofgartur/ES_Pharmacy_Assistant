import { IconProp } from '@fortawesome/fontawesome-svg-core';

interface IClientDetailsItem {
    data: string;
    icon: IconProp;
}

export  default IClientDetailsItem;