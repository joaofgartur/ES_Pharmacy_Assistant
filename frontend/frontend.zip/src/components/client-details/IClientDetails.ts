interface IClientDetails {
    name: string;
    phone: string;
    email: string;
    photo: any;
}

export default IClientDetails;