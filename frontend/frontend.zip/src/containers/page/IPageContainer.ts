interface IPageContainer {
    children: string | JSX.Element | JSX.Element[]
}

export default IPageContainer
