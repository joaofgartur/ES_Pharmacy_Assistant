interface IAccount {
    jwt: string | undefined,
    email: string | undefined
}

export default IAccount
