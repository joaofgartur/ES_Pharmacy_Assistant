interface IAuthContainer {
    children: JSX.Element
}

export default IAuthContainer
